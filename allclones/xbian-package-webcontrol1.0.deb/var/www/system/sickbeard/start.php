<?php
    exec('sudo /var/www/system/sickbeard/start.sh > /dev/null 2>&1 &');
?>

