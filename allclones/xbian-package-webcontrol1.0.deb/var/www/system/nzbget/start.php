<?php
    exec('sudo /var/www/system/nzbget/start.sh > /dev/null 2>&1 &');
?>

