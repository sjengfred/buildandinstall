#!/bin/bash

sudo /etc/init.d/couchpotato restart >/dev/null 2>&1 &

exit 0
