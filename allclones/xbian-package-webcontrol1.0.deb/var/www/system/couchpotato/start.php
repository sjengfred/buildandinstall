<?php
    exec('sudo /var/www/system/couchpotato/start.sh > /dev/null 2>&1 &');
?>

