<?php
    exec('sudo /var/www/system/xbmc/start.sh > /dev/null 2>&1 &');
?>
