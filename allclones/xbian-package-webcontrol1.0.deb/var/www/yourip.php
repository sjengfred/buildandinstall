<?php
  $yourip = "http://0.0.0.0";
?>
