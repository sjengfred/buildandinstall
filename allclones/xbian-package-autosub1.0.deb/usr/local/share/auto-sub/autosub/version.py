autosubversion='Beta 0.5.7'
configversion=2
dbversion=3